package com.example.gym;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gym.data.AdminSQLiteOpenHelper;
import com.example.gym.data.Utilidades;


public class RegistrarEjercicioActivity extends AppCompatActivity {

    EditText /*txt_Id, */txt_Nombre, txt_Pesos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_ejercicio);

        //txt_Id = (EditText)findViewById(R.id.txtId);
        txt_Nombre = (EditText)findViewById(R.id.txtNombre);
        txt_Pesos = (EditText)findViewById(R.id.txtPesos);

    }

    public void OnClick(View view){
        registrarEjercicios();
        //registrarEjerciciosSql();
    }

    private void registrarEjerciciosSql(){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "db_ejercicios", null, 1);

        SQLiteDatabase db = admin.getReadableDatabase();

        //Insert into ejercicio (id, nombre, peso) values (123, 'Press', 78)

        String insert = "INSERT INTO "+Utilidades.TABLA_EJERCICIO+" (/*+Utilidades.CAMPO_ID+,*/ "+ Utilidades.CAMPO_NOMBRE+", "+Utilidades.CAMPO_PESO+")" +
                "VALUES (/*+txt_Id.getText().toString()+,*/ '"+txt_Nombre.getText().toString()+"', "+txt_Pesos.getText().toString()+")";
        db.execSQL(insert);

    }

    private void registrarEjercicios(){
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "db_ejercicios", null, 1);

        SQLiteDatabase db = admin.getReadableDatabase();

        ContentValues values = new ContentValues();
        //values.put(Utilidades.CAMPO_ID, txt_Id.getText().toString());
        values.put(Utilidades.CAMPO_NOMBRE, txt_Nombre.getText().toString());
        values.put(Utilidades.CAMPO_PESO, txt_Pesos.getText().toString());

        Long idResultante = db.insert(Utilidades.TABLA_EJERCICIO, Utilidades./*CAMPO_ID*/CAMPO_NOMBRE, values);

        Toast.makeText(getApplicationContext(), "Registrado: " +idResultante, Toast.LENGTH_SHORT).show();
        db.close();

    }

    private void VolveR(){
        Intent it = new Intent(this, EjerciciosActivity.class);
        startActivity(it);
    }

    public void onClick2(View view){
        VolveR();
    }

}
