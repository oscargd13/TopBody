package com.example.gym;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;

        import android.app.ProgressDialog;
        import android.content.Intent;
        import android.os.Bundle;
        import android.text.TextUtils;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

        import com.google.android.gms.tasks.OnCompleteListener;
        import com.google.android.gms.tasks.Task;
        import com.google.firebase.auth.AuthResult;
        import com.google.firebase.auth.FirebaseAuth;
        import com.google.firebase.auth.FirebaseAuthUserCollisionException;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText cajaEmail;
    private EditText cajaContraseña;
    private Button btnRegister;
    private Button btnLogin;
    private ProgressDialog progressDialog;

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseAuth = FirebaseAuth.getInstance();

        //Referenciamos los views
        cajaEmail = (EditText) findViewById(R.id.Email);
        cajaContraseña = (EditText) findViewById(R.id.Contraseña);

        btnRegister = (Button) findViewById(R.id.Register);
        btnLogin = (Button) findViewById(R.id.Login);

        progressDialog = new ProgressDialog(this);

        btnLogin.setOnClickListener(this);
        btnRegister.setOnClickListener(this);

    }

    public void BotonGuardar(){

        //Obtenemos el email y la contraseña desde las cajas de texto
        String email = cajaEmail.getText().toString().trim();
        String password  = cajaContraseña.getText().toString().trim();

        //Verificamos que las cajas de texto no esten vacías
        if(TextUtils.isEmpty(email)){
            Toast.makeText(this,"Se debe ingresar un email",Toast.LENGTH_LONG).show();
            return;
        }

        if(TextUtils.isEmpty(password)){
            Toast.makeText(this,"Se debe ingresar la contraseña",Toast.LENGTH_LONG).show();
            return;
        }
        progressDialog.setMessage("Realizando registro...");
        progressDialog.show();


        //creamos un nuevo usuario
        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){

                            Toast.makeText(MainActivity.this,"Se ha registrado correctamente "+ cajaEmail.getText(),Toast.LENGTH_LONG).show();
                        }else {
                            if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                                Toast.makeText(MainActivity.this, "Ya existe ese usuario", Toast.LENGTH_SHORT).show();
                            }else {
                                Toast.makeText(MainActivity.this, "No se pudo registrar el usuario ", Toast.LENGTH_LONG).show();
                            }
                        }
                        progressDialog.dismiss();
                    }
                });
    }
    private void BotonLogear(){
       /* Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);*/

        final String email = cajaEmail.getText().toString().trim();
        String password  = cajaContraseña.getText().toString().trim();


        if(TextUtils.isEmpty(email)){
            Toast.makeText(this,"Se debe ingresar un email",Toast.LENGTH_LONG).show();
            return;
        }

        if(TextUtils.isEmpty(password)){
            Toast.makeText(this,"Se debe ingresar la contraseña",Toast.LENGTH_LONG).show();
            return;
        }
        progressDialog.setMessage("Conectando...");
        progressDialog.show();


        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){

                            Toast.makeText(MainActivity.this,"Bienvenido "+ cajaEmail.getText(),Toast.LENGTH_LONG).show();

                            Intent intent1 = new Intent(getApplication(), Main2Activity.class);
                            startActivity(intent1);

                        }else {
                            if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                                Toast.makeText(MainActivity.this, "Ya existe ese usuario", Toast.LENGTH_SHORT).show();
                            }else {
                                Toast.makeText(MainActivity.this, "No se pudo logear el usuario ", Toast.LENGTH_LONG).show();
                            }
                        }
                        progressDialog.dismiss();
                    }
                });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case  R.id.Register:
               BotonGuardar();
               break;
            case R.id.Login:
                BotonLogear();
        }


    }
}
