package com.example.gym.data;

public class Ejercicio {

    //private Integer id;
    private String nombre;
    private Integer peso;

    //public Integer getId() { return id; }

    //public void setId(Integer id) { this.id = id; }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getPeso() {
        return peso;
    }

    public void setPeso(Integer peso) {
        this.peso = peso;
    }

    public Ejercicio(/*Integer id, */String nombre, Integer peso) {
        //this.id = id;
        this.nombre = nombre;
        this.peso = peso;
    }

    public Ejercicio(){

    }
}