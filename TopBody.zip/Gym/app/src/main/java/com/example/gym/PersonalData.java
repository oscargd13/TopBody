package com.example.gym;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class PersonalData extends AppCompatActivity {

    Spinner spinner;
    SharedPreferences datos;
    SharedPreferences.Editor editor;

    //private Spinner spinner;
    private EditText txtPeso;
    private EditText txtAltura;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.personal_data);

        datos = getSharedPreferences("datos", Context.MODE_PRIVATE);
        editor = datos.edit();

        final int sexo = datos.getInt("sexo", 0);

        txtPeso = (EditText) findViewById(R.id.editText4);
        txtAltura = (EditText) findViewById(R.id.editText5);
        spinner = (Spinner) findViewById(R.id.spinner);

        final List<String> simpleList = new ArrayList<>();
        simpleList.add("Hombre");
        simpleList.add("Mujer");

        ArrayAdapter simpleAdapter = new ArrayAdapter<>
                (PersonalData.this, R.layout.support_simple_spinner_dropdown_item, simpleList);

        spinner.setAdapter(simpleAdapter);

        spinner.setSelection(sexo);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                editor.putInt("sexo", position).commit();

                Toast.makeText(PersonalData.this, simpleList.get(position), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        SharedPreferences datos = getSharedPreferences("datos", Context.MODE_PRIVATE);
        txtPeso.setText(datos.getString("peso", ""));
        txtAltura.setText(datos.getString("altura", ""));


    }

    //Método botón Aceptar

    public void Aceptar(View view){
        SharedPreferences misDatos = getSharedPreferences("datos", Context.MODE_PRIVATE);

        SharedPreferences.Editor Obj_editor = misDatos.edit();
        Obj_editor.putString("peso", txtPeso.getText().toString());
        Obj_editor.putString("altura", txtAltura.getText().toString());

        final int sexo = misDatos.getInt("sexo", 0);

        Obj_editor.commit(); // Confirmar para guardar
        finish();

        BotonAceptar();
    }

    public void BotonAceptar(){
        String str_peso = txtPeso.getText().toString().trim();
        String str_altura = txtAltura.getText().toString().trim();

        if(TextUtils.isEmpty(str_peso)){
            Toast.makeText(this, "Debe ingresar su peso", Toast.LENGTH_SHORT).show();
            return;
        }

        if(TextUtils.isEmpty(str_altura)){
            Toast.makeText(this, "Debe ingresar su altura", Toast.LENGTH_SHORT).show();
            return;
        }

    }

}