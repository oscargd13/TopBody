package com.example.gym;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void MisDatos(){
        Intent misdatos = new Intent(this, PersonalData.class);
        startActivity(misdatos);
    }

    public void Rutina(){
        Intent rutina = new Intent(this, RutinaActivity.class);
        startActivity(rutina);
    }

    public void Ejercicios(){
        Intent ejercicios = new Intent(this, EjerciciosActivity.class);
        startActivity(ejercicios);
    }


    public void onClick(View view) {
        switch (view.getId()){
            case  R.id.btnRutina:
                Rutina();
                break;
            case R.id.btnMisDatos:
                MisDatos();
                break;
            case R.id.btnEjercicios:
                Ejercicios();
        }


    }

}


