package com.example.gym;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.gym.data.AdminSQLiteOpenHelper;

public class EjerciciosActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicios);

        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "db_ejercicios", null, 1);


    }

    public void volver(){
        Intent it = new Intent(this, Main2Activity.class);
        startActivity(it);
    }

    public void onClick(View view){
        Intent miIntent = null;
        switch (view.getId()){
            case R.id.btnRegistrar:
                miIntent = new Intent(this, RegistrarEjercicioActivity.class);
                break;
            case R.id.btnConsultar:
                miIntent = new Intent(this, ConsultarEjerciciosActivity.class);
                break;
            case R.id.btnLista:
                miIntent = new Intent(this, ListaEjerciciosActivity.class);
                break;
            case R.id.floatingActionButton4:
                volver();
                break;

        }
        if (miIntent!=null){
            startActivity(miIntent);
        }
    }


}
