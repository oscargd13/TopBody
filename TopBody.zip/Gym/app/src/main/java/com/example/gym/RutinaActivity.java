package com.example.gym;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class RutinaActivity extends AppCompatActivity {

    TextView muestraRutina;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rutina2);

        muestraRutina = (TextView) findViewById(R.id.muestrarutinaa);
        muestraRutina.setMovementMethod(new ScrollingMovementMethod());

        SharedPreferences datos = getSharedPreferences("datos", Context.MODE_PRIVATE);
        int peso = Integer.parseInt(datos.getString("peso", ""));
        int altura = Integer.parseInt(datos.getString("altura", ""));
        int sex = datos.getInt("sexo", 0);

        if (sex == 0){
            if (peso < 70 && altura < 175){
                int a = R.raw.rutinahombre3;
                cargarRutina(a);
            }else if (peso < 80 && altura < 180){
                int a = R.raw.rutinahombre1;
                cargarRutina(a);
            }else {
                int a = R.raw.rutinahombre2;
                cargarRutina(a);
            }
        }else if (sex == 1){
            if (peso < 75 && altura < 170){
                int a = R.raw.rutinamujer1;
                cargarRutina(a);
            }else {
                int a = R.raw.rutinamujer2;
                cargarRutina(a);
            }

        }

    }

    public void cargarRutina(int rutina){
        InputStream is = getResources().openRawResource(rutina);
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String line;
        String entireFile = "";
        try {
            while((line = br.readLine()) != null) { // <--------- place readLine() inside loop
                entireFile += (line + "\n"); // <---------- add each line to entireFile
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        muestraRutina.setText(entireFile); // <------- assign entireFile to TextView
        //break;
    }


    public void Main(View view){
        Intent main = new Intent(this, Main2Activity.class);
        startActivity(main);
    }

}

