package com.example.gym;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gym.data.AdminSQLiteOpenHelper;
import com.example.gym.data.Utilidades;

public class ConsultarEjerciciosActivity extends AppCompatActivity {

    EditText txt_Id, txt_Nombre, txt_Pesos;

    AdminSQLiteOpenHelper admin;
    private View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar_ejercicios);

        admin = new AdminSQLiteOpenHelper(getApplicationContext(), "db_ejercicios", null, 1);

        //txt_Id = (EditText)findViewById(R.id.txtIdConsulta);
        txt_Nombre = (EditText)findViewById(R.id.txtNombreConsulta);
        txt_Pesos = (EditText)findViewById(R.id.txtPesosConsulta);
    }

    public void onClick(View view){

        switch (view.getId()) {
            case R.id.btnBuscar:
                consultar();
                //consultarSql();
                break;
            case R.id.btnActualizar:
                actualizarEjercicio();
                break;
            case R.id.btnEliminar:
                eliminarEjercicio();
                break;
            case R.id.floatingActionButton3:
                Volver();
        }
    }

    private void eliminarEjercicio() {
        SQLiteDatabase db = admin.getWritableDatabase();
        String[] parametros = {/*txt_Id*/txt_Nombre.getText().toString()};

        db.delete(Utilidades.TABLA_EJERCICIO, Utilidades./*CAMPO_ID*/CAMPO_NOMBRE+"=?", parametros);
        Toast.makeText(getApplicationContext(), "Ejercicio eliminado", Toast.LENGTH_SHORT).show();
        /*txt_Id*/txt_Nombre.setText("");
        Limpiar();
        db.close();
    }

    private void actualizarEjercicio() {
        SQLiteDatabase db = admin.getWritableDatabase();
        String[] parametros = {/*txt_Id*/txt_Nombre.getText().toString()};
        ContentValues values = new ContentValues();
        values.put(Utilidades.CAMPO_PESO, txt_Pesos.getText().toString());

        db.update(Utilidades.TABLA_EJERCICIO, values, Utilidades./*CAMPO_ID*/CAMPO_NOMBRE+ "=?", parametros);
        Toast.makeText(getApplicationContext(), "Ejercicio actualizado", Toast.LENGTH_SHORT).show();
        db.close();

    }

    private void consultar() {
        SQLiteDatabase db = admin.getReadableDatabase();
        String[] parametros = {/*txt_Id*/txt_Nombre.getText().toString()};
        String[] campos = {/*Utilidades.CAMPO_NOMBRE, */Utilidades.CAMPO_PESO};

        try {
            Cursor cursor = db.query(Utilidades.TABLA_EJERCICIO, campos, Utilidades./*CAMPO_ID*/CAMPO_NOMBRE+"=?", parametros, null, null, null);
            cursor.moveToFirst();
            //txt_Nombre.setText(cursor.getString(0));
            txt_Pesos.setText(cursor.getString(/*1*/0));
            cursor.close();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(), "No existe", Toast.LENGTH_SHORT).show();
            Limpiar();
        }

    }
    private void Volver(){
        Intent it = new Intent(this, EjerciciosActivity.class);
        startActivity(it);
    }

    private void consultarSql() {
        SQLiteDatabase db = admin.getReadableDatabase();
        String[] parametros = {/*txt_Id*/txt_Nombre.getText().toString()};

        try {
            // SELECT nombre, peso FROM ejercicio WHERE codigo=?
            Cursor cursor = db.rawQuery("SELECT /*+Utilidades.CAMPO_NOMBRE+*/ "+Utilidades.CAMPO_PESO+" FROM "+Utilidades.TABLA_EJERCICIO+" WHERE "+Utilidades./*CAMPO_ID*/CAMPO_NOMBRE+" =?", parametros);

            cursor.moveToFirst();
            //txt_Nombre.setText(cursor.getString(0));
            txt_Pesos.setText(cursor.getString(/*1*/0));

        }catch (Exception e){
            Toast.makeText(getApplicationContext(), "No existe", Toast.LENGTH_SHORT).show();
            Limpiar();
        }
    }


    private void Limpiar(){
        //txt_Nombre.setText("");
        txt_Pesos.setText("");
    }

}
