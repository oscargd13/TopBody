package com.example.gym;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gym.data.AdminSQLiteOpenHelper;
import com.example.gym.data.Ejercicio;
import com.example.gym.data.Utilidades;

import java.util.ArrayList;

public class ListaEjerciciosActivity extends AppCompatActivity {

    Spinner comboEjercicios;
    TextView txtNombre, txtPeso;
    ArrayList<String> listaEjercicios;;
    ArrayList<Ejercicio> ejerciciosList;

    AdminSQLiteOpenHelper admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_ejercicios);

        admin = new AdminSQLiteOpenHelper(getApplicationContext(), "db_ejercicios", null, 1);


        comboEjercicios = (Spinner) findViewById(R.id.spinner);

        txtNombre = (TextView) findViewById(R.id.txtMuestraNombre);
        txtPeso = (TextView) findViewById(R.id.txtMuestraPeso);

        consultarListaEjercicios();

        ArrayAdapter<CharSequence> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, listaEjercicios);

        comboEjercicios.setAdapter(adapter);

        comboEjercicios.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (position != 0){
                    txtNombre.setText(ejerciciosList.get(position-1).getNombre());
                    txtPeso.setText(ejerciciosList.get(position-1).getPeso().toString() + " kg");
                }else {
                    txtNombre.setText("");
                    txtPeso.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void consultarListaEjercicios() {
        SQLiteDatabase db = admin.getReadableDatabase();

        Ejercicio ej = null;
        ejerciciosList = new ArrayList<Ejercicio>();

        //SELECT * FROM ejercicio
        Cursor cursor = db.rawQuery("SELECT * FROM "+ Utilidades.TABLA_EJERCICIO, null);

        while (cursor.moveToNext()){
            ej = new Ejercicio();
            ej.setNombre(cursor.getString(0));
            ej.setPeso(cursor.getInt(1));

            ejerciciosList.add(ej);
        }
        obtenerLista();
    }

    private void obtenerLista() {
        listaEjercicios = new ArrayList<String>();
        listaEjercicios.add("Seleccione");

        for (int i=0; i<ejerciciosList.size();i++){
            listaEjercicios.add(ejerciciosList.get(i).getNombre());
        }
    }

    private void Volver(){
        Intent ite = new Intent(this, EjerciciosActivity.class);
        startActivity(ite);
    }

    public void onClick(View view){
        Volver();
    }
}
