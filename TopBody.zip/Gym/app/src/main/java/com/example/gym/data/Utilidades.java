package com.example.gym.data;

public class Utilidades {

    // Constantes campos tabla ejercicio

    public static final String TABLA_EJERCICIO="ejercicio";
    //public static final String CAMPO_ID="id";
    public static final String CAMPO_NOMBRE="nombre";
    public static final String CAMPO_PESO="telefono";

    //public static final String CREAR_TABLA_EJERCICIO="CREATE TABLE "+TABLA_EJERCICIO+" ("+CAMPO_ID+" INTEGER, "+CAMPO_NOMBRE+" TEXT, "+CAMPO_PESO+" INTEGER)";

    public static final String CREAR_TABLA_EJERCICIO="CREATE TABLE "+TABLA_EJERCICIO+" ("+CAMPO_NOMBRE+" TEXT, "+CAMPO_PESO+" INTEGER)";

}
